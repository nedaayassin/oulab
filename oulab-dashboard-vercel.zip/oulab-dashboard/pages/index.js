import dynamic from 'next/dynamic'

const OulabDashboard = dynamic(() => import('@/components/OulabDashboard'), { ssr: false })

export default function Home() {
  return (
    <main>
      <OulabDashboard />
    </main>
  )
}
