import React, { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Bus } from "lucide-react";

export default function OulabDashboard() {
  const [overall, setOverall] = useState(72);
  const [phase1, setPhase1] = useState(88);
  const [phase2, setPhase2] = useState(46);

  const tracks = [
    { label: "مسار منهجية البرامج", value: 100, status: "مكتمل" },
    { label: "مسار الدليل التشغيلي والتنفيذي", value: 90, status: "قيد التنفيذ" },
    { label: "مسار الدليل الإجرائي", value: 30, status: "قيد التنفيذ" },
    { label: "مسار الحقائب للدورات التدريبية", value: 95, status: "قيد التنفيذ" },
    { label: "مسار الموارد البشرية", value: 70, status: "قيد التنفيذ" },
    { label: "مسار الشراكات الاستراتيجية", value: 20, status: "قيد التنفيذ" },
    { label: "مسار خطة الاستدامة", value: 0, status: "لم يبدأ" },
  ];

  const [routeProgress, setRouteProgress] = useState(82);

  return (
    <div dir="rtl" className="relative min-h-screen w-full bg-[#0C0C0C] text-white font-salford overflow-hidden">
      <BrandStyles />

      {/* Watermark as background */}
      <div
        className="absolute inset-0 bg-center bg-no-repeat bg-contain opacity-[0.04] pointer-events-none select-none"
        style={{
          backgroundImage:
            "url('https://drive.google.com/uc?export=view&id=1L8mzDwPyCXRl1nGMieRGDrQjUJhxlon0')",
        }}
      />

      {/* Content */}
      <header className="px-5 md:px-10 py-6 flex items-center justify-between gap-4 relative z-10">
        <div className="flex items-center gap-3">
          <div className="size-10 rounded-xl bg-gradient-to-br from-[#7941E5] via-[#9324C6] to-[#F9326F]" />
          <div>
            <h1 className="text-xl md:text-2xl font-ada">لوحة مؤشرات أولاب</h1>
            <p className="text-xs text-white/60">نظرة فورية على تقدم المشروع ومسارات العمل</p>
          </div>
        </div>
        <div className="hidden md:flex items-center gap-2 text-xs text-white/70">
          <span className="inline-block size-3 rounded-full bg-[#F9326F]" /> تحديث لحظي
        </div>
      </header>

      <main className="px-5 md:px-10 pb-10 grid grid-cols-1 xl:grid-cols-3 gap-6 relative z-10">
        <section className="xl:col-span-2 grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <h3 className="card-title">نسبة إنجاز مشروع أولاب</h3>
            <div className="flex items-center justify-center py-6">
              <ProgressCircle value={overall} size={170} stroke={16} />
            </div>
          </Card>
          <Card>
            <h3 className="card-title">المرحلة الأولى — الإعداد والتجهيز</h3>
            <div className="flex items-center justify-center py-6">
              <ProgressCircle value={phase1} size={170} stroke={16} />
            </div>
          </Card>
          <Card>
            <h3 className="card-title">المرحلة الثانية</h3>
            <div className="flex items-center justify-center py-6">
              <ProgressCircle value={phase2} size={170} stroke={16} />
            </div>
          </Card>

          <Card className="md:col-span-3">
            <h3 className="card-title mb-4">مسارات الباص</h3>
            <div className="space-y-4">
              {tracks.map((t, i) => (
                <TrackLine key={i} label={t.label} value={t.value} status={t.status} />
              ))}
            </div>
          </Card>
        </section>

        <section className="xl:col-span-1">
          <Card>
            <h3 className="card-title mb-6">لوحة التحكم (تفاعلية)</h3>
            <ControlSlider label="إنجاز مشروع أولاب" value={overall} setValue={setOverall} />
            <ControlSlider label="المرحلة الأولى — الإعداد والتجهيز" value={phase1} setValue={setPhase1} />
            <ControlSlider label="المرحلة الثانية" value={phase2} setValue={setPhase2} />
            <div className="h-px bg-white/10 my-6" />
            <ControlSlider label="موقع الباص باتجاه ميناء جدة" value={routeProgress} setValue={setRouteProgress} />
            <p className="text-xs text-white/60 mt-2">يمكنك تحريك المؤشر لتغيير موضع الباص على الخط (الصين ← جدة).</p>
          </Card>
        </section>

        <section className="xl:col-span-3">
          <Card>
            <h3 className="card-title mb-3">خط الرحلة — الصين ← ميناء جدة</h3>
            <div className="relative w-full">
              <div className="flex items-center justify-between text-sm text-white/80 mb-2">
                <span>الصين</span>
                <span>جدة</span>
              </div>
              <div className="relative h-12">
                <div className="absolute left-0 right-0 top-1/2 -translate-y-1/2 h-2 rounded-full bg-white/10 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-[#7941E5] via-[#9324C6] to-[#F9326F]"
                    style={{ width: `${routeProgress}%` }}
                  />
                </div>
                <motion.div
                  initial={{ x: 0 }}
                  animate={{ x: `${routeProgress}%` }}
                  transition={{ type: "spring", stiffness: 60, damping: 12 }}
                  className="absolute -top-1 left-0 -translate-x-1/2"
                >
                  <motion.div
                    animate={{ y: [0, -6, 0] }}
                    transition={{ repeat: Infinity, duration: 1.6, ease: "easeInOut" }}
                    className="flex items-center gap-2"
                  >
                    <div className="p-2 rounded-xl bg-white text-[#0C0C0C] shadow-lg">
                      <Bus className="w-6 h-6" />
                    </div>
                    <span className="text-xs text-white/80 bg-white/10 px-2 py-1 rounded-lg backdrop-blur">باص أولاب</span>
                  </motion.div>
                </motion.div>
              </div>
              <div className="mt-3 flex items-center justify-between text-xs text-white/60">
                <span>تاريخ الشراء</span>
                <span>{routeProgress}%</span>
                <span>تاريخ الوصول — <span className='text-white/80'>7 سبتمبر</span></span>
              </div>
            </div>
          </Card>
        </section>
      </main>

      <footer className="px-5 md:px-10 pb-8 text-xs text-white/50 relative z-10">
        ملاحظة: الأرقام قابلة للتعديل من لوحة التحكم. يوصى بربطها لاحقًا بمصدر بيانات حقيقي.
      </footer>
    </div>
  );
}

function Card({ children, className = "" }) {
  return (
    <div
      className={
        "rounded-2xl p-5 md:p-6 bg-white/5 backdrop-blur border border-white/10 shadow-[0_10px_30px_rgba(0,0,0,0.3)] " +
        className
      }
    >
      {children}
    </div>
  );
}

function ControlSlider({ label, value, setValue }) {
  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-2">
        <label className="text-sm text-white/80">{label}</label>
        <span className="text-xs text-white/60">{value}%</span>
      </div>
      <input
        type="range"
        min={0}
        max={100}
        value={value}
        onChange={(e) => setValue(parseInt(e.target.value))}
        className="w-full accent-[#F9326F]"
      />
    </div>
  );
}

function TrackLine({ label, value, status }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <div className="flex items-center gap-2">
          <span className="inline-block size-2 rounded-full bg-[#EF883E]" />
          <p className="text-sm">{label}</p>
        </div>
        <div className="text-xs text-white/70 flex items-center gap-2">
          <span className={`px-2 py-0.5 rounded-full bg-white/10 border border-white/10`}>
            {status}
          </span>
          <span>{value}%</span>
        </div>
      </div>
      <div className="h-2 rounded-full bg-white/10 overflow-hidden">
        <div
          className="h-full rounded-full bg-gradient-to-r from-[#7941E5] via-[#9324C6] to-[#F9326F]"
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  );
}

function ProgressCircle({ value, size = 160, stroke = 14 }) {
  const radius = useMemo(() => (size - stroke) / 2, [size, stroke]);
  const circumference = useMemo(() => 2 * Math.PI * radius, [radius]);
  const offset = useMemo(
    () => circumference - (value / 100) * circumference,
    [circumference, value]
  );

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="rgba(255,255,255,0.12)"
          strokeWidth={stroke}
          fill="none"
        />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="url(#grad)"
          strokeLinecap="round"
          strokeWidth={stroke}
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: offset }}
          transition={{ type: "spring", stiffness: 70, damping: 16 }}
        />
        <defs>
          <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#7941E5" />
            <stop offset="50%" stopColor="#9324C6" />
            <stop offset="100%" stopColor="#F9326F" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="text-3xl md:text-4xl font-ada">{value}%</div>
        <div className="text-[10px] uppercase tracking-widest text-white/60">Progress</div>
      </div>
    </div>
  );
}

function BrandStyles() {
  return (
    <style>{`
      @font-face {
        font-family: 'Salford Sans Arabic VF';
        src: local('Salford Sans Arabic VF');
        font-weight: 100 900;
        font-style: normal;
        font-display: swap;
      }
      @font-face {
        font-family: '29LT Ada Round VF';
        src: local('29LT Ada Round VF');
        font-weight: 100 900;
        font-style: normal;
        font-display: swap;
      }
      .font-salford { font-family: 'Salford Sans Arabic VF', ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Noto Sans', 'Apple Color Emoji', 'Segoe UI Emoji'; }
      .font-ada { font-family: '29LT Ada Round VF', 'Salford Sans Arabic VF', ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial; }
      .card-title { @apply font-ada text-base md:text-lg text-white; }
    `}</style>
  );
}
